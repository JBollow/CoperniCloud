
coperniCloud.controller('aboutController', function($scope) {
    $scope.message = 'Do we need this?';
});