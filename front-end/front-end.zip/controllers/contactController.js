coperniCloud.controller('contactController', function($scope) {
    $scope.message = 'Here shall be the impressum!';
});