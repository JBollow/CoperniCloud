coperniCloud.controller('mainController', ['$scope', '$timeout', 'leafletData', function ($scope, $timeout, leafletData) {

    $scope.searchedItem = "";
    $scope.showResults = false;

    angular.extend($scope, {
        center: {
            lat: 51.82956,
            lng: 7.276709,
            zoom: 5
        },
        markers: $scope.markers,
        defaults: {
            tileLayer: "http://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png",
            zoomControlPosition: 'bottomright',
            tileLayerOptions: {
                opacity: 0.9,
                detectRetina: true,
                reuseTiles: true,
            },
            scrollWheelZoom: true
        },
        layers: {
            baselayers: {
                DarkMatter: {
                    name: 'DarkMatter',
                    url: 'http://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png',
                    type: 'xyz',
                    // layerOptions: {
                    //     apikey: ,
                    //     mapid: ''
                    // }
                },
                Grayscale: {
                    name: 'Grayscale',
                    url: 'http://korona.geog.uni-heidelberg.de/tiles/roadsg/x={x}&y={y}&z={z}',
                    type: 'xyz'
                },
                OpenStreetMap_DE: {
                    name: 'OSMDE',
                    url: 'http://{s}.tile.openstreetmap.de/tiles/osmde/{z}/{x}/{y}.png',
                    attribution: '© <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>',
                    type: 'xyz'
                }
            }

        }
    });

    // A global reference is set.
    leafletData.getMap('map').then(function (m) {
        $scope.routeMap = m;
    });

    //Watches for the variable change
    $scope.$watch('searchedItem', function () {
        if ($scope.searchedItem !== "") {
            console.log($scope.searchedItem);
            //start the search here
            $scope.resultsArray = [];
            for (var i=0; i < $scope.exampleArray.length; i++) {
                if ($scope.exampleArray[i].name.toLowerCase().match($scope.searchedItem.toLowerCase())) {
                    $scope.resultsArray.push($scope.exampleArray[i]);
                }
            }

            $timeout(function () {
                $scope.showResults = true;
            }, 0);

        }
    });

    $scope.exampleArray = [{
            name: "january",
            startDate: "01.01.2017",
            endDate: "31.01.2017"
        },
        {
            name: "february",
            startDate: "01.02.2017",
            endDate: "28.02.2017"
        },
        {
            name: "march",
            startDate: "01.03.2017",
            endDate: "31.03.2017"
        },
        {
            name: "april",
            startDate: "01.04.2017",
            endDate: "30.04.2017"
        },
        {
            name: "may",
            startDate: "01.05.2017",
            endDate: "31.05.2017"
        },
        {
            name: "june",
            startDate: "01.06.2017",
            endDate: "30.04.2017"
        },
    ];
}]);