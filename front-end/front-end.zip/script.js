// create the module and name it coperniCloud
// also include ngRoute for all our routing needs
var coperniCloud = angular.module('coperniCloud', ['ngRoute', 'leaflet-directive']);